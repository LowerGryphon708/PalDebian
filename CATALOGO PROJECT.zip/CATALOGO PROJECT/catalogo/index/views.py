from django.shortcuts import render
from django.http import JsonResponse
import requests
import json

# Create your views here.
# IP de la base de datos
#IP_Orion='localhost'
IP_Orion="192.168.1.77"
Port_Orion="1026"

# Consulta una entidad específica
def search(juego):
    try:
        '''Sirve para buscar un juego'''
        url='http://'+IP_Orion+':'+Port_Orion+'/v2/entities?q=Titulo~='+juego
        headers={"Accept":"application/json"}
        response=requests.get(url,headers=headers)
        # print(response.status_code)
        response=response.content.decode("utf-8").replace("'", '"')
        response_JSON=json.loads(response)
        return response_JSON[0]
    
    except:
        return 'Nada'


# Esta función responde un html llamado index
def index(request):
    # print('asdasd')
    
    return render(request, "index.html")



def busqueda(request):
    #Ir por los datos del juego solicitado
    juego = request.GET.get('texto'," ")
    resultado=search(str(juego).upper())

    # Hacer la busqueda en la base de datos  con juego




    context= {
                'resultado' : resultado,
            }

    return JsonResponse(context)