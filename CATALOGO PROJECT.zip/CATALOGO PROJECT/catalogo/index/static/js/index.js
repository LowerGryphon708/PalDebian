
function buscar(){
    // alert('Elminmna')
    const xhr = new XMLHttpRequest();


    xhr.open("GET", "/search?texto="+document.getElementById('texto').value);
    xhr.send();
    xhr.responseType = "json"; 
    xhr.onload = () => {
    if (xhr.status==200){
    //   alert(xhr.response['espacio']);
      if (xhr.response['resultado'] == 'Nada'){
        document.getElementById('titulo').value= ' ';  
        document.getElementById('portable').value= ' '; 
        document.getElementById('genero').value= ' '; 
        document.getElementById('desarrollador').value= ' '; 
        document.getElementById('year').value= ' ';  
      }
      else{
        document.getElementById('titulo').value= xhr.response['resultado']['Titulo']['value'];  
        document.getElementById('portable').value= xhr.response['resultado']['Portable']['value'];  
        document.getElementById('genero').value= xhr.response['resultado']['Genero']['value'];  
        document.getElementById('desarrollador').value= xhr.response['resultado']['Desarrollador']['value'];  
        document.getElementById('year').value= xhr.response['resultado']['Year']['value'];  

      }
    }
    else{
      alert("Error en el servidor web")
    }
    };   
  }
  